wget -O output.zip https://www.dropbox.com/s/yxmv91ec8w7lpoa/output.zip?dl=1
unzip output.zip