wget -O context_selection_output/pytorch_model.bin  https://www.dropbox.com/s/y6d8mrl5fbtxofg/pytorch_model.bin?dl=1
wget -O context_selection_output/training_args.bin  https://www.dropbox.com/s/ew0ne6xor6yveuv/training_args.bin?dl=1
wget -O context_selection_output/vocab.txt  https://www.dropbox.com/s/3035mdmhdf3j56l/vocab.txt?dl=1

wget -O question_answering_output/pytorch_model.bin  https://www.dropbox.com/s/t9rth7mj3sm3r6f/pytorch_model.bin?dl=0
wget -O question_answering_output/pytorch_model.bin  https://www.dropbox.com/s/hh23oibp1x1skv9/training_args.bin?dl=0
wget -O question_answering_output/pytorch_model.bin  https://www.dropbox.com/s/wr0b1emokj4idcs/vocab.txt?dl=0
