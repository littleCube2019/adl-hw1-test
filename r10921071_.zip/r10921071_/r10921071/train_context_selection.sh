python3 context_selection.py \
  --do_train \
  --do_eval \
  --model_name_or_path hfl/chinese-roberta-wwm-ext \
  --output_dir context_selection_output \
  --train_file processed_data/train.json \
  --validation_file processed_data/valid.json \
  --context_file data/context.json \
  --cache_dir ./cache/ \
  --pad_to_max_length \
  --max_seq_length 512 \
  --learning_rate 3e-5 \
  --num_train_epochs 1 \
  --warmup_ratio 0.1 \
  --overwrite_output_dir \
  --per_device_train_batch_size 1 \
  --per_device_eval_batch_size 2 \
  --gradient_accumulation_steps 32  
  #--model_name_or_path hfl/chinese-roberta-wwm-ext \