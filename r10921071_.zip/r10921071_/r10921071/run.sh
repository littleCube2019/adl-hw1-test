python3 ./processed_data/convert_format.py $2 

python3 context_selection.py \
  --model_name_or_path ./context_selection_output \
  --cache_dir ./cache/ \
  --output_dir ./processed_data/ \
  --pad_to_max_length \
  --test_file ./processed_data/test.json \
  --context_file $1 \
  --output_file ./processed_data/context_selection_result.json \
  --do_predict \
  --max_seq_length 512 \
  --per_device_eval_batch_size 4 \

python3 question_answering.py \
  --model_name_or_path ./question_answering_output \
  --cache_dir ./cache/ \
  --output_dir ./prediction \
  --pad_to_max_length \
  --test_file ./processed_data/context_selection_result.json \
  --context_file $1 \
  --do_predict \
  --max_seq_length 512 \
  --doc_stride 128 \
  --per_device_eval_batch_size 4 \



python3 processed_data/make_output.py