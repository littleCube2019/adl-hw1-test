import jsonlines
from pathlib import Path
import sys
p = Path('./pred/generated_predictions.txt')
raw_pred_text = p.read_text().split('\n')
input = jsonlines.open(sys.argv[1])

print(sys.argv[1],input)
_id = [i['id'] for i in input]
data = [{'title': title, 'id': id} for title, id in zip(raw_pred_text, _id)]
with jsonlines.open(sys.argv[2], mode='w') as writer:
    writer.write_all(data)
