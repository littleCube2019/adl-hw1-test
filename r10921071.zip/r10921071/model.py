from typing import Dict

import torch
from torch.nn import Embedding




class SeqClassifier(torch.nn.Module):
    def __init__(
        self,
        embeddings: torch.tensor,
        hidden_size: int,
        num_layers: int,
        dropout: float,
        bidirectional: bool,
        num_class: int,
        attn_num_heads=2 ,
        use_attn = True ,
    ) -> None:
        super(SeqClassifier, self).__init__()
        self.embed = Embedding.from_pretrained(embeddings, freeze=False)
        # TODO: model architecture (Done)
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.dropout = dropout
        self.bidirectional = bidirectional
        self.num_class = num_class
        self.attn_num_heads = attn_num_heads
        
        self.lstm = torch.nn.LSTM(embeddings.size(1), 
                                self.hidden_size, 
                                self.num_layers, 
                                dropout=self.dropout, 
                                bidirectional=self.bidirectional, 
                                batch_first=True)
        self.lstm2 = torch.nn.LSTM(self.encoder_output_size, 
                                self.hidden_size, 
                                self.num_layers, 
                                dropout=self.dropout, 
                                bidirectional=self.bidirectional, 
                                batch_first=True)
      
        
        self.W_1 = torch.nn.Linear(2*hidden_size, 64)
        self.W_2 = torch.nn.Linear(64, 128)
        self.attn_output = torch.nn.Linear(128*2*hidden_size, self.encoder_output_size)
        
        

        self.dropout_layer = torch.nn.Dropout(self.dropout)
        
        self.attention = torch.nn.MultiheadAttention(2*hidden_size,
                                                     4,
                                                   dropout=self.dropout,
                                                    batch_first = True)
        
        
        self.output_layer = torch.nn.Sequential(
            torch.nn.Dropout(self.dropout),
            torch.nn.Linear(self.encoder_output_size, self.num_class),
            torch.nn.ReLU()

        )
    @property
    def encoder_output_size(self) -> int:
        # TODO: calculate the output dimension of rnn (Done)
        # for ouput_layer (need to know hidden layer size)
        if self.bidirectional:
            return 2*self.hidden_size
        return self.hidden_size
    

    def attention_net(self, lstm_output):
        att = self.W_1(lstm_output)
        att = self.dropout_layer(att)
        att = (torch.tanh(att))
        att = self.W_2(att)
        att = self.dropout_layer(att)
        att = att.permute(0, 2, 1)
        att = torch.nn.functional.softmax(att, dim=2)

        return att
    def forward(self, batch) -> Dict[str, torch.Tensor]:
        # TODO: implement model forward
        # batch ["text"] : vocab id , batch["intent"] : output id , batch["id"]: id
        res = {}
        X = batch["text"]
        if "intent" in batch:
            y = batch["intent"]
        else:
            y = None
        # model structure
        #seq_len = torch.tensor([min(len(x), batch["max_len"]) for x in X]) Should set in batch
        #print(seq_len)
       
        X = self.embed(X)
        
        X = torch.nn.utils.rnn.pack_padded_sequence(X ,batch["seq_len"] ,batch_first=True,enforce_sorted=False) #pack to reduce padding zero

        X , (hn,_) = self.lstm(X)
        
        
        X ,_ = torch.nn.utils.rnn.pad_packed_sequence(X,batch_first=True )
        
        
        if self.bidirectional:
            hn = (torch.cat((hn[-1], hn[-2]), axis=-1) )  # size = (batch , num_class)
        else:
            hn = hn[-1]  # size = (batch , num_class)
        
     
        
     
        
        X , _ = self.attention(X,X,X)
        
        
        attn_weight = self.attention_net(X)
        hn = torch.bmm(attn_weight, X)
        X = self.attn_output(hn.view(-1, hn.size()[1]*hn.size()[2]))
        
        y_pred = self.output_layer(X)
        res["y_pred"] = torch.argmax(y_pred , dim=1)
  
        
        if y!=None:
            res["loss"] = torch.nn.functional.cross_entropy(y_pred , y)
        
        return res

class SeqTagger(torch.nn.Module):
    def __init__(
        self,
        embeddings: torch.tensor,
        hidden_size: int,
        num_layers: int,
        dropout: float,
        bidirectional: bool,
        num_class: int,
        
       
    ) -> None:
        super(SeqTagger, self).__init__()
        self.embed = Embedding.from_pretrained(embeddings, freeze=False)
        # model architecture
        self.embed_dim = embeddings.size(1)
        
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bidirectional = bidirectional
        self.num_class = num_class
        self.dropout = dropout
        
    
        self.cnn =torch.nn.Sequential(
            torch.nn.Conv1d(self.embed_dim, self.embed_dim, 5),
            torch.nn.Dropout(self.dropout),
            torch.nn.ReLU(),
        )

        
        self.lstm = torch.nn.LSTM(self.embed_dim, self.hidden_size, self.num_layers, dropout=dropout, bidirectional=self.bidirectional, batch_first=True)

 
        self.output_layer = torch.nn.Sequential(
                torch.nn.Dropout(self.dropout),
                torch.nn.Linear(2*self.hidden_size, self.num_class)
        )
        self.W_1 = torch.nn.Linear(2*hidden_size, 32)
        self.W_2 = torch.nn.Linear(32, 64)
        self.attn_output = torch.nn.Linear(64*2*hidden_size, 2*hidden_size)
        self.dropout_layer = torch.nn.Dropout(self.dropout)
    def attention_net(self, lstm_output):
        att = self.W_1(lstm_output)
        att = self.dropout_layer(att)
        att = (torch.tanh(att))
        att = self.W_2(att)
        att = self.dropout_layer(att)
        att = att.permute(0, 2, 1)
        att = torch.nn.functional.softmax(att, dim=2)

        return att



    def forward(self, batch) -> Dict[str, torch.Tensor]:
        res = dict()

        X = batch['tokens'] # [batch_size, max_len]
        y = None
        if 'tags' in batch:
            y = batch['tags']
        X = self.embed(X) # [batch_size, max_len, embed_dim]

        # CNN part
        """
        X = X.permute(0, 2, 1) 
        X = self.cnn(X) 
        X = X.permute(0, 2, 1) 
        """
        #LSTM part
        packed_x = torch.nn.utils.rnn.pack_padded_sequence(X, batch['seq_len'], batch_first=True , enforce_sorted=False)
     
        X, _ = self.lstm(packed_x)
        X, _ = torch.nn.utils.rnn.pad_packed_sequence(X, batch_first=True) # [batch_size, max_len, hid_dim])


        
        
        y_pred= self.output_layer(X) #batch size [batch size , max_len , num_class ]

        res["y_pred"] = torch.argmax(y_pred , dim=2)

      
        
        res["loss"] = 0
        if y!=None:
            for i in range(len(batch["each_len"])):  
                ell = batch["each_len"][i]
                res["loss"] +=  torch.nn.functional.cross_entropy(y_pred[i , :ell ,] , y[i, :ell])
                    
    
       

        return res