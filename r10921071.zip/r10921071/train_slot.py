import json
import pickle
from argparse import ArgumentParser, Namespace
from pathlib import Path
from typing import Dict

import torch
from torch.optim import Adam
from torch.utils.data import DataLoader
from tqdm import tqdm, trange

from dataset import SeqTaggingClsDataset
from model import SeqTagger
from utils import Vocab

#from seqeval.scheme import IOB2
#from seqeval.metrics import classification_report
TRAIN = "train"
DEV = "eval"
SPLITS = [TRAIN, DEV]


def main(args):
    with open(args.cache_dir / "vocab.pkl", "rb") as f:
        vocab: Vocab = pickle.load(f)

    

    tag_idx_path = args.cache_dir / "tag2idx.json"
    tag2idx: Dict[str, int] = json.loads(tag_idx_path.read_text())

    data_paths = {split: args.data_dir / f"{split}.json" for split in SPLITS}
    data = {split: json.loads(path.read_text()) for split, path in data_paths.items()}
    datasets: Dict[str, SeqTagDataset] = {
        split: SeqTaggingClsDataset(split_data, vocab, tag2idx, args.max_len)
        for split, split_data in data.items()
    }

    # create DataLoader for train / dev datasets
    dataloaders = {}
    for s in SPLITS:
        dataloaders[s] = DataLoader(datasets[s], args.batch_size, shuffle=True , collate_fn = datasets[s].collate_fn)
    
    embeddings = torch.load(args.cache_dir / "embeddings.pt")
    
    model = SeqTagger(embeddings, 
                          args.hidden_size, 
                          args.num_layers, 
                          args.dropout, 
                          args.bidirectional, 
                          datasets["train"].num_classes).to(args.device)
    
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer  , 10)

    epoch_pbar = trange(args.num_epoch, desc="Epoch")
   
    best_acc = 0
    history_loss = {"train":[] , "eval":[]}
    for epoch in epoch_pbar:
        print("Epoch:", epoch , end="")
        
    
        # TODO: Training loop - iterate over train dataloader and update model weights(Done)
        for batch in tqdm(dataloaders["train"]):
            model.train() # tell model to be trained
            optimizer.zero_grad()
            # Need move to GPU in order to avoid "Expected all tensors to be on the same device" Error
            batch["tokens"] = batch["tokens"].to(args.device)
            batch["tags"] = batch["tags"].to(args.device)
            
            output = model(batch)
            loss = output['loss']
            history_loss["train"].append(loss.item())
            loss.backward()
            optimizer.step()
            
        scheduler.step()
        
            
        print("\ntraining loss:" , history_loss["train"][-1])
        acc = 0
        #y_preds = []
        #ys = []
        # TODO: Evaluation loop - calculate accuracy and save model weights
        for batch in dataloaders["eval"]:
            model.eval()
            # Need move to GPU in order to avoid "Expected all tensors to be on the same device" Error
            batch["tokens"] = batch["tokens"].to(args.device)
            batch["tags"] = batch["tags"].to(args.device)
            output = model(batch)
            loss = output['loss']
            history_loss["eval"].append(loss.item())
            
          
            
            
            for i in range(output["y_pred"].size(0)):
           
                y_pred = output["y_pred"][i , : batch["each_len"][i]]
                y = batch["tags"][i , :batch["each_len"][i]]
                
                #y_preds.append(y_pred.tolist())
                #ys.append(y.tolist())
                
                acc += (batch["each_len"][i].to(args.device)) == torch.sum( y_pred.eq(y.to(args.device)))
        
        #y_pred_text = [[datasets["eval"].idx2label(y) for y in text ] for text in y_preds]
        #y_text = [[datasets["eval"].idx2label(y) for y in text ]  for text in ys]
      
        
        #print(classification_report(y_text, y_pred_text,scheme=IOB2, mode='strict'))
        
        acc = acc/len(datasets["eval"])
        if best_acc < acc:
            best_acc = acc
            torch.save({"model":model.state_dict() , "val_acc":acc , "training_loss": history_loss["train"][-1]} , str(args.ckpt_dir) + "/best.pt")
        print("\nvalidation loss:" , history_loss["eval"][-1] , "validation acc:", acc.item()) 
        #torch.save({"model":model.state_dict() , "val_acc":acc , "training_loss": history_loss["train"][-1]} ,  str(args.ckpt_dir) + "/epoch-"+str(epoch) )
        
    print("best val acc:",best_acc)
def parse_args() -> Namespace:
    parser = ArgumentParser()
    parser.add_argument(
        "--data_dir",
        type=Path,
        help="Directory to the dataset.",
        default="./data/slot/",
    )
    parser.add_argument(
        "--cache_dir",
        type=Path,
        help="Directory to the preprocessed caches.",
        default="./cache/slot/",
    )
    parser.add_argument(
        "--ckpt_dir",
        type=Path,
        help="Directory to save the model file.",
        default="./ckpt/slot/",
    )

    # data
    parser.add_argument("--max_len", type=int, default=128)

    # model
    parser.add_argument("--hidden_size", type=int, default=128) #128
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--dropout", type=float, default=0.7)
    parser.add_argument("--bidirectional", type=bool, default=True)

    # optimizer
    parser.add_argument("--lr", type=float, default=6e-4)

    # data loader
    parser.add_argument("--batch_size", type=int, default=128)

    # training
    parser.add_argument(
        "--device", type=torch.device, help="cpu, cuda, cuda:0, cuda:1", default="cuda"
    )
    parser.add_argument("--num_epoch", type=int, default=100)

    args = parser.parse_args()
    return args


if __name__ == "__main__":
    args = parse_args()
    args.ckpt_dir.mkdir(parents=True, exist_ok=True)
    main(args)

