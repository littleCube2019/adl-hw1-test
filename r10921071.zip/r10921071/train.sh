export CUDA_VISIBLE_DEVICES=0

python3 run_summarization.py \
    --model_name_or_path google/mt5-small \
    --do_train \
    --do_eval \
    --train_file $1 \
    --validation_file $2 \
    --dataset_config "3.0.0" \
    --source_prefix "summarize: " \
    --output_dir ./output \
    --text_column maintext \
    --summary_column title \
    --per_device_train_batch_size=2 \
    --per_device_eval_batch_size=4 \
    --overwrite_output_dir \
    --predict_with_generate \
    --overwrite_output_dir \
    --save_strategy no \
    --adafactor \
    --evaluation_strategy steps \
    --eval_steps 1000 \
    --gradient_accumulation_steps 8 \
    --num_beams 7 \
    #--fp16 yes \
