wget -O best.pt https://www.dropbox.com/s/gb0n09sjiqhmukf/best.pt?dl=1 -P ckpt/intent
wget -O best.pt https://www.dropbox.com/sh/rkxfv2ljok5py4t/AAAXdE-TLZTbA1ew8hHkMxUOa?dl=1 -P ckpt/slot