wget -O ckpt/intent/best.pt  https://www.dropbox.com/s/gb0n09sjiqhmukf/best.pt?dl=1 
wget -O ckpt/slot/best.pt   https://www.dropbox.com/sh/rkxfv2ljok5py4t/AAAXdE-TLZTbA1ew8hHkMxUOa?dl=1 