wget -O ckpt/intent/best.pt  https://www.dropbox.com/s/mshzcfhtylg9opx/best.pt?dl=1 
wget -O ckpt/slot/best.pt   https://www.dropbox.com/s/3n8sysd6dhswgft/best.pt?dl=1 