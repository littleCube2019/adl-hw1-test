# Download glove
sh preprocess.sh

# train my model 
### intent 
python train_intent.py --device=cuda

### slot 
python train_slot.py --device=cuda

# test my model 
sh intent_cls.sh
sh slot_tag.sh
