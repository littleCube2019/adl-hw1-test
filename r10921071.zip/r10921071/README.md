# Environment (As default)
# If you have conda, we recommend you to build a conda environment called "adl-hw1"
make
conda activate adl-hw1
pip install -r requirements.txt
# Otherwise
pip install -r requirements.in

# Download glove (As default)
bash preprocess.sh

# test my model (As default)
bash intent_cls.sh /path/to/test.json /path/to/pred.csv
bash slot_tag.sh /path/to/test.json /path/to/pred.csv

# train my model 
### intent 
python train_intent.py --device=cuda

### slot 
python train_slot.py --device=cuda


