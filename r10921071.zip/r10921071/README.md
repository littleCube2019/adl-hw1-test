# prediction (how reproduce my output)
bash run.sh /path/to/context.json /path/to/test.json  /path/to/pred/prediction.csv
EX:
bash run.sh sh run.sh data/context.json data/test.json predict/output.csv



# training 
bash train_context_selection.sh /path/to/context.json /path/to/valid.json  /path/to/pred/train.json
bash train_QA.sh /path/to/context.json /path/to/valid.json  /path/to/pred/train.json
bash predict_context_selection.sh /path/to/context.json /path/to/test.json
bash predict_QA.sh /path/to/context.json 
python3 processed_data/make_output.py
mv output.csv /path/to/pred/prediction.csv