# prediction
bash ./download.sh
bash ./run.sh /path/to/input.jsonl /path/to/output.jsonl

# training
bash train.sh /path/to/train.jsonl /path/to/validation.jsonl
