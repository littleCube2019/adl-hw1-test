# Download glove
bash preprocess.sh

# train my model 
### intent 
python train_intent.py --device=cuda

### slot 
python train_slot.py --device=cuda

# test my model 
bash intent_cls.sh
bash slot_tag.sh
