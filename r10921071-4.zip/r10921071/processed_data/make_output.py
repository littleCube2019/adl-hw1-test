import json
import csv
name = "./prediction/test_predictions.json"


with open(name, 'r') as f:
    data = json.load(f)




header = ['id', 'answer']
# 1. Open a new CSV file
with open('output.csv', 'w') as file:
    # 2. Create a CSV writer
    
    writer = csv.writer(file)
    writer.writerow(header)
    for _id in data:
        writer.writerow([_id , data[_id]])