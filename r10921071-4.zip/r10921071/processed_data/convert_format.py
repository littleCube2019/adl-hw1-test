import json
import os
import sys

name = sys.argv[1].split("/")[-1]

with open(sys.argv[1], 'r') as f:
    data = json.load(f)


output_dir = "processed_data/"
if "answer" in data[0]:
    for i in range(len(data)):
        data[i]["answer"]["text"] = [c for c in data[i]["answer"]["text"]]
        data[i]["answer"]["answer_start"] = data[i]["answer"].pop('start')
        data[i]["answer"]["answer_start"] = [data[i]["answer"]["answer_start"]]
else:
    for i in range(len(data)):
        data[i]["answer"] = {}
        data[i]["answer"]["text"] = []
        data[i]["answer"]["answer_start"] = []
        data[i]["relevant"] = 0
json.dump({'data': data}, open(output_dir + name, 'w',encoding='utf-8'), indent=2, ensure_ascii=False)