wget -O context_selection_output.zip https://www.dropbox.com/s/40sq122cx4bf5uh/context_selection_output.zip?dl=1
wget -O question_answering_output.zip  https://www.dropbox.com/s/nojgv4vwulndlok/question_answering_output.zip?dl=1

unzip context_selection_output.zip
unzip question_answering_output.zip
